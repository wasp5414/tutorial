from PIL import Image, ImageFilter,ImageChops

img1 = Image.open('max_entropy_ngc6093_0010.png')
img2 = Image.open('ngc6093.jpg')

reimg1 = img1.crop((740,203,4337,3889))
reimg1 = reimg1.resize((img2.size[0],img2.size[1]))

pix1=reimg1.load()
pix2=img2.load()

resimg=Image.new("RGB",(img2.size[0],img2.size[1]))
pix3=resimg.load()

'''
for i in range(0,img1.size[0]-1):
    for j in range(0,img1.size[1]-1):
        if pix1[i,j] == (255,255,255) and pix1[i+1,j+1] != (255,255,255):
            print(i,j)
for i in range(1, img1.size[0]):
    for j in range(1, img1.size[1]):
        if pix1[i, j] == (255, 255, 255) and pix1[i-1, j-1] != (255, 255, 255):
            print(i,j)
'''

'''
#sum1
for i in range(img2.size[0]):
    for j in range(img2.size[1]):
        pix3[i,j]=( round((pix1[i,j][0]+pix2[i,j][0])/2) , round((pix1[i,j][1]+pix2[i,j][1])/2) , round((pix1[i,j][2]+pix2[i,j][2])/2) )

resimg.save("ex4_sum.bmp")
'''

'''
#sum2
sumimg=Image.blend(reimg1,img2,0.5)
sumimg.save("ex4_sum2.bmp")


#sub
subimg=ImageChops.subtract(img2,reimg1)
subimg.save("ex4_sub.bmp")


#mul
for i in range(img2.size[0]):
    for j in range(img2.size[1]):
        pix3[i,j]=( pix1[i,j][0]*pix2[i,j][0] , pix1[i,j][1]*pix2[i,j][1] , pix1[i,j][2]*pix2[i,j][2] )

resimg.save("ex4_mult.bmp")
'''

'''
#div
for i in range(img2.size[0]):
    for j in range(img2.size[1]):
        if pix2[i,j][0] == 0 or pix2[i,j][1] == 0 or pix2[i,j][2] == 0:
            pix3[i,j]=(0,0,0)
        else:
            pix3[i,j]=( int(pix1[i,j][0]/pix2[i,j][0]*100) , int(pix1[i,j][1]/pix2[i,j][1]*100) , int(pix1[i,j][2]/pix2[i,j][2]*100) )

resimg.save("ex4_div.bmp")
'''


#mask
mask=Image.new("RGB",img2.size)
mskpix=mask.load()

for i in range(0,img2.size[0]):
    for j in range(0,img2.size[1]):
        if (i - img2.size[0] / 2) ** 2 + (j - img2.size[1] / 2) ** 2 < (img2.size[0] * 0.1) ** 2:
            mskpix[i,j]=pix2[i,j]

mask.save('ex4_msk.bmp')




